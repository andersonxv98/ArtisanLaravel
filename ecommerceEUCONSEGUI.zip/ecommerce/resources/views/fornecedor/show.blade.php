<?php
    //Composer Update
   //php artisan keygenerate
    //php artisan migrate 
    //php artisan serve
        //lembrte o wamp deve estar em execução

        //php artisan  make:model fornecedor --migration
        // no cmd: copy .env.example .env
                //modificar o arquivo nos paramestro necessário tipo: nomedo db: ecommerce
        //php artisan make:model fornecedor --migration(isso cria o db pular os passos intermediarios)
        //update-database
        //fazer o front
        //register
        //categoria
        //fazer fornecedores (tentar pelo menos)